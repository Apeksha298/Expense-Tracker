package expenseTrackerPack.expenseTrackerApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenseTrackerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
