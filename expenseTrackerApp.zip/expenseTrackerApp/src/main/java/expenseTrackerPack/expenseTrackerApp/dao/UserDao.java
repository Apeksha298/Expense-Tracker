package expenseTrackerPack.expenseTrackerApp.dao;

import expenseTrackerPack.expenseTrackerApp.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserDao extends JpaRepository<User, Long> {
    // Find user by email (useful for authentication or uniqueness checks)
	 Optional<User> findByEmail(String email);
    // Check if an email exists
    boolean existsByEmail(String email);
}
