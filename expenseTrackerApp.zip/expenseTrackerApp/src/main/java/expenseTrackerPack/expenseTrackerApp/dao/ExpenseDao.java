package expenseTrackerPack.expenseTrackerApp.dao;

import expenseTrackerPack.expenseTrackerApp.entity.Expense;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface ExpenseDao extends JpaRepository<Expense, Long> {
    // Find all expenses for a given user
    List<Expense> findByUserId(Long userId);

    // Find all expenses for a given user with a date filter
    List<Expense> findByUserIdAndDateBetween(Long userId, LocalDate startDate, LocalDate endDate);
}
