package expenseTrackerPack.expenseTrackerApp.service;

import expenseTrackerPack.expenseTrackerApp.dao.ExpenseDao;
import expenseTrackerPack.expenseTrackerApp.dao.UserDao;
import expenseTrackerPack.expenseTrackerApp.entity.Expense;
import expenseTrackerPack.expenseTrackerApp.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class ExpenseService {

    @Autowired
    private ExpenseDao expenseDao;

    @Autowired
    private UserDao userDao;
 // Create a new expense
    public Expense createExpense(Expense expense) {
        validateUserExists(expense.getUser().getId());
        validateDate(expense.getDate());
        return expenseDao.save(expense);
    } 


    // Get all expenses
    public List<Expense> getAllExpenses() {
        return expenseDao.findAll();
    }

    // Get expenses by user
    public List<Expense> getExpensesByUser(Long userId) {
        validateUserExists(userId);
        return expenseDao.findByUserId(userId);
    }

    // Get expense by ID
    public Optional<Expense> getExpenseById(Long id) {
        return expenseDao.findById(id);
    }

    // Update an expense
    public Expense updateExpense(Long id, Expense updatedExpense) {
        Optional<Expense> existingExpenseOpt = expenseDao.findById(id);
        if (existingExpenseOpt.isPresent()) {
            Expense existingExpense = existingExpenseOpt.get();
            validateUserExists(updatedExpense.getUser().getId());
            validateDate(updatedExpense.getDate());

            existingExpense.setTitle(updatedExpense.getTitle());
            existingExpense.setAmount(updatedExpense.getAmount());
            existingExpense.setDate(updatedExpense.getDate());
            existingExpense.setUser(updatedExpense.getUser());

            return expenseDao.save(existingExpense);
        } else {
            throw new RuntimeException("Expense not found with ID: " + id);
        }
    }

    // Delete an expense
    public void deleteExpense(Long id) {
        if (expenseDao.existsById(id)) {
            expenseDao.deleteById(id);
        } else {
            throw new RuntimeException("Expense not found with ID: " + id);
        }
    }

    // Validate user existence
    private void validateUserExists(Long userId) {
        if (!userDao.existsById(userId)) {
            throw new RuntimeException("User not found with ID: " + userId);
        }
    }

    // Validate expense date
    private void validateDate(LocalDate date) {
        if (date.isAfter(LocalDate.now())) {
            throw new RuntimeException("Expense date cannot be in the future.");
        }
    }
}
