package expenseTrackerPack.expenseTrackerApp.service;

import expenseTrackerPack.expenseTrackerApp.dao.UserDao;
import expenseTrackerPack.expenseTrackerApp.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserDao userDao;

    // Create a new user
    public User createUser(User user) {
        return userDao.save(user);
    }

    // Get all users
    public List<User> getAllUsers() {
        return userDao.findAll();
    }

    // Get user by ID
    public Optional<User> getUserById(Long id) {
        return userDao.findById(id);
    }

    // Update user by ID
    public User updateUser(Long id, User user) {
        Optional<User> existingUser = userDao.findById(id);
        if (existingUser.isPresent()) {
            user.setId(id);
            return userDao.save(user);
        } else {
            throw new RuntimeException("User not found");
        }
    }

    // Delete user by ID
    public void deleteUser(Long id) {
        userDao.deleteById(id);
    }

    // Find a user by email (for login purposes)
    public Optional<User> getUserByEmail(String email) {
        return userDao.findByEmail(email);
    }
}
