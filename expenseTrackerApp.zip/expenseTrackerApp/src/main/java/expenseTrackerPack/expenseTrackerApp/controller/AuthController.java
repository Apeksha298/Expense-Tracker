/*package expenseTrackerPack.expenseTrackerApp.controller;

import expenseTrackerPack.expenseTrackerApp.dto.LoginRequest;
import expenseTrackerPack.expenseTrackerApp.entity.User;
import expenseTrackerPack.expenseTrackerApp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("http://localhost:4200")  // Allowing frontend app to make requests
public class AuthController {

    @Autowired
    private UserService userService;

    // Login endpoint (POST /api/login)
    @PostMapping("/api/login")
    public ResponseEntity<String> login(@RequestBody LoginRequest loginRequest) {
        String email = loginRequest.getEmail();
        String password = loginRequest.getPassword();

        // Authenticate the user
        User user = userService.authenticate(email, password);

        if (user != null) {
            // User authenticated successfully
            return ResponseEntity.ok("Login successful");
        } else {
            // Invalid credentials response
            return ResponseEntity.status(401).body("Invalid email or password");
        }
    }
}


*/