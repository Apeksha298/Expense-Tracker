package expenseTrackerPack.expenseTrackerApp.controller;

import expenseTrackerPack.expenseTrackerApp.entity.Expense;
import expenseTrackerPack.expenseTrackerApp.entity.User;
import expenseTrackerPack.expenseTrackerApp.service.ExpenseService;
import expenseTrackerPack.expenseTrackerApp.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin("http://localhost:4200") 
@RestController
public class ExpenseController {

    @Autowired
    private ExpenseService expenseService;
    

 // Create a new expense
    @PostMapping("/api/expenses")
    public ResponseEntity<Expense> createExpense(@Validated @RequestBody Expense expense) {
        try {
            Expense createdExpense = expenseService.createExpense(expense);
            return ResponseEntity.ok(createdExpense);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    // Get all expenses
    @GetMapping("/api/expenses")
    public ResponseEntity<List<Expense>> getAllExpenses() {
        List<Expense> expenses = expenseService.getAllExpenses();
        return ResponseEntity.ok(expenses);
    }

    // Get expenses by user ID
    @GetMapping("/api/expenses/user/{userId}")
    public ResponseEntity<List<Expense>> getExpensesByUser(@PathVariable Long userId) {
        try {
            List<Expense> expenses = expenseService.getExpensesByUser(userId);
            return ResponseEntity.ok(expenses);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // Get expense by ID
    @GetMapping("/api/expenses/{id}")
    public ResponseEntity<Expense> getExpenseById(@PathVariable Long id) {
        Optional<Expense> expenseOpt = expenseService.getExpenseById(id);
        return expenseOpt.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Update expense by ID
    @PutMapping("/api/expenses/{id}")
    public ResponseEntity<Expense> updateExpense(@PathVariable Long id, @Validated @RequestBody Expense expense) {
        try {
            Expense updatedExpense = expenseService.updateExpense(id, expense);
            return ResponseEntity.ok(updatedExpense);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // Delete expense by ID
    @DeleteMapping("/api/expenses/{id}")
    public ResponseEntity<Void> deleteExpense(@PathVariable Long id) {
        try {
            expenseService.deleteExpense(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
