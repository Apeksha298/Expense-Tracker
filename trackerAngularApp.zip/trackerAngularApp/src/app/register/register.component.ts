import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: false,
  
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  user = {
    name: '',
    email: '',
    password: ''
  };

  constructor(private http: HttpClient, private router: Router) {}

  register() {
    this.http.post('http://localhost:8080/api/register', this.user).subscribe(
      (response: any) => {
        Swal.fire('Success', 'Registration successful! Please log in.', 'success').then(() => {
          // Navigate to login page after successful registration
          this.router.navigate(['/login']);
        });
      },
      (error) => {
        Swal.fire('Error', 'User already exists or invalid input!', 'error');
      }
    );
  }

}
