import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration, withEventReplay } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ExpenseService } from './expense.service';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { AddexpenseComponent } from './addexpense/addexpense.component';
import { ViewexpenseComponent } from './viewexpense/viewexpense.component';
import { AboutComponent } from './about/about.component';
import { EditExpenseComponent } from './edit-expense/edit-expense.component';
import { RegisterComponent } from './register/register.component';
import { FooterComponent } from './footer/footer.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    HeaderComponent,
    AddexpenseComponent,
    ViewexpenseComponent,
    AboutComponent,
    EditExpenseComponent,
    RegisterComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [
    provideClientHydration(withEventReplay()),
    ExpenseService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
