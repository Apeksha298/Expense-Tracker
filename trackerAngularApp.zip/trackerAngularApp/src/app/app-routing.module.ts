import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { AddexpenseComponent } from './addexpense/addexpense.component';
import { ViewexpenseComponent } from './viewexpense/viewexpense.component';
import { AboutComponent } from './about/about.component';
import { EditExpenseComponent } from './edit-expense/edit-expense.component';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component:RegisterComponent},
  { path: 'home', component: HomeComponent },
  { path: 'addexpense', component: AddexpenseComponent },
  { path: 'viewexpense', component: ViewexpenseComponent },
  { path: 'about', component: AboutComponent },
  { path: 'edit-expense/:id', component: EditExpenseComponent },
  { path: '', redirectTo: '/login', pathMatch: 'full' },  // Default route redirect to login
  { path: 'view-expenses', component: ViewexpenseComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
