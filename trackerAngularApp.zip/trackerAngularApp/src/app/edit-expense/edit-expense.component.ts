import { Component } from '@angular/core';
import { Expense ,User} from '../models/expense';
import { ExpenseService } from '../expense.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-edit-expense',
  standalone: false,
  
  templateUrl: './edit-expense.component.html',
  styleUrl: './edit-expense.component.css'
})
export class EditExpenseComponent {
  expense: Expense = new Expense(0, '', 0, new Date(), new User(0));  // Initialize with a default User
  errorMessage: string = '';

  constructor(
    private route: ActivatedRoute,
    private expenseService: ExpenseService,
    public router: Router
  ) {}

  ngOnInit(): void {
    const id = +this.route.snapshot.paramMap.get('id')!;  // Get the expense ID from the URL
    this.getExpense(id);
  }

  // Fetch the expense to edit
  getExpense(id: number): void {
    this.expenseService.getExpenseById(id).subscribe({
      next: (data) => this.expense = data,
      error: (err) => {
        this.errorMessage = 'Failed to load expense details';
        Swal.fire('Error', 'Failed to load expense details', 'error');  // Show error Swal
      }
    });
  }

  // Save the edited expense
  saveExpense(): void {
    if (!this.expense.title || this.expense.amount <= 0 || !this.expense.date) {
      this.errorMessage = 'Please fill out all fields correctly';
      Swal.fire('Warning', 'Please fill out all fields correctly', 'warning');  // Show warning Swal
      return;
    }

    if (this.expense.id === null) {
      this.errorMessage = 'Expense ID is missing';
      Swal.fire('Error', 'Expense ID is missing', 'error');  // Show error Swal
      return;
    }

    this.expenseService.updateExpense(this.expense.id, this.expense).subscribe({
      next: (data) => {
        console.log('Expense updated successfully:', data);
        Swal.fire('Success', 'Expense updated successfully!', 'success').then(() => {
          this.router.navigate(['/viewexpense']);  // Navigate after success
        });
      },
      error: (err) => {
        console.error('Error updating expense:', err);
        this.errorMessage = 'Failed to save expense';
        Swal.fire('Error', 'Failed to save expense', 'error');  // Show error Swal
      }
    });
  }

}
