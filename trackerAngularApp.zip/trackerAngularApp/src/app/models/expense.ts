// User model
export class User {
  constructor(
    public id: number,         // User ID
    public name?: string,      // Optional: User's name
    public email?: string,     // Optional: User's email
    public password?: string   // Optional: User's password
  ) {}
}

// Expense model
export class Expense {
  constructor(
    public id: number | null,    // Expense ID (null for new expenses)
    public title: string,        // Expense title
    public amount: number,       // Expense amount
    public date: Date,           // Expense date
    public user: User            // Associated user object
  ) {}
}

