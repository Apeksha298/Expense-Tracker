import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Expense } from '../models/expense';
import { ExpenseService } from '../expense.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-viewexpense',
  standalone: false,
  templateUrl: './viewexpense.component.html',
  styleUrls: ['./viewexpense.component.css']
})
export class ViewexpenseComponent implements OnInit {
  expenses: Expense[] = [];
  errorMessage: string = '';

  constructor(private expenseService: ExpenseService, private router: Router) {}

  ngOnInit(): void {
    this.getExpenses();
  }

  // Fetch all expenses
  getExpenses(): void {
    this.expenseService.getAllExpenses().subscribe({
      next: (data) => (this.expenses = data),
      error: (err) => {
        this.errorMessage = 'Failed to load expenses';
        Swal.fire({
          title: 'Error!',
          text: 'Failed to load expenses. Please try again later.',
          icon: 'error',
          confirmButtonText: 'OK'
        });
      }
    });
  }

  // Delete an expense
  deleteExpense(id: number): void {
    Swal.fire({
      title: 'Are you sure?',
      text: 'Do you want to delete this expense?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.isConfirmed) {
        this.expenseService.deleteExpense(id).subscribe({
          next: () => {
            this.expenses = this.expenses.filter((exp) => exp.id !== id);
            Swal.fire({
              title: 'Deleted!',
              text: 'Expense has been deleted.',
              icon: 'success',
              confirmButtonText: 'OK'
            });
          },
          error: (err) => {
            this.errorMessage = 'Failed to delete expense';
            Swal.fire({
              title: 'Error!',
              text: 'Failed to delete expense. Please try again.',
              icon: 'error',
              confirmButtonText: 'OK'
            });
          }
        });
      }
    });
  }

  // Navigate to Edit Expense
  editExpense(id: number | null): void {
    if (id === null) {
      Swal.fire({
        title: 'Error!',
        text: 'Invalid expense ID.',
        icon: 'error',
        confirmButtonText: 'OK'
      });
      return;
    }

    this.router.navigate(['/edit-expense', id]);
  }
}
