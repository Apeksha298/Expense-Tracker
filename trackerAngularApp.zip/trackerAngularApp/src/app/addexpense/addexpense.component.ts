import { Component, OnInit } from '@angular/core';
import { Expense, User } from '../models/expense';
import { ExpenseService } from '../expense.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2'; // Import SweetAlert2

@Component({
  selector: 'app-addexpense',
  standalone: false,
  templateUrl: './addexpense.component.html',
  styleUrls: ['./addexpense.component.css']
})
export class AddexpenseComponent implements OnInit {
  errorMessage: string = '';
  newExpense: Expense = new Expense(null, '', 0, new Date(), new User(1)); // Initialize with default values

  constructor(private expenseService: ExpenseService, private router: Router) {}

  ngOnInit(): void {}

  // Add a new expense
  addExpense(): void {
    if (!this.newExpense.title || this.newExpense.amount <= 0 || !this.newExpense.date) {
      this.errorMessage = 'Please fill out all fields correctly';
      Swal.fire({
        title: 'Error!',
        text: 'Please fill out all fields correctly.',
        icon: 'error',
        confirmButtonText: 'OK'
      });
      return;
    }

    this.expenseService.createExpense(this.newExpense).subscribe({
      next: (data) => {
        this.newExpense = new Expense(null, '', 0, new Date(), new User(1)); // Reset the form
        Swal.fire({
          title: 'Success!',
          text: 'Expense added successfully!',
          icon: 'success',
          confirmButtonText: 'OK'
        });
      },
      error: (err) => {
        this.errorMessage = 'Failed to add expense';
        Swal.fire({
          title: 'Error!',
          text: 'Failed to add expense. Please try again.',
          icon: 'error',
          confirmButtonText: 'OK'
        });
      }
    });
  }
}  